
  # Travel Booking Website Design

  This is a code bundle for Travel Booking Website Design. The original project is available at https://www.figma.com/design/oGqfLw7Z67QhUp2HBA4KjM/Travel-Booking-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  