import { useState } from 'react';
import { HomePage } from './components/HomePage';
import { SearchResultsPage } from './components/SearchResultsPage';
import { PackageDetailsPage } from './components/PackageDetailsPage';
import { BookingPage } from './components/BookingPage';
import { PaymentPage } from './components/PaymentPage';
import { ConfirmationPage } from './components/ConfirmationPage';
import { Navbar } from './components/Navbar';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'search' | 'details' | 'booking' | 'payment' | 'confirmation'>('home');
  const [selectedPackage, setSelectedPackage] = useState<any>(null);

  const navigate = (page: typeof currentPage, packageData?: any) => {
    setCurrentPage(page);
    if (packageData) {
      setSelectedPackage(packageData);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <Navbar onNavigate={navigate} currentPage={currentPage} />
      
      {currentPage === 'home' && <HomePage onNavigate={navigate} />}
      {currentPage === 'search' && <SearchResultsPage onNavigate={navigate} />}
      {currentPage === 'details' && <PackageDetailsPage onNavigate={navigate} packageData={selectedPackage} />}
      {currentPage === 'booking' && <BookingPage onNavigate={navigate} packageData={selectedPackage} />}
      {currentPage === 'payment' && <PaymentPage onNavigate={navigate} packageData={selectedPackage} />}
      {currentPage === 'confirmation' && <ConfirmationPage onNavigate={navigate} />}
    </div>
  );
}
