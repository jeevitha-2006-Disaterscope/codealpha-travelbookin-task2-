import { useState } from 'react';
import { MapPin, Star, Clock, Users, CheckCircle, Calendar, Utensils, Hotel, Plane, Camera, ChevronRight } from 'lucide-react';
import { Footer } from './Footer';

interface PackageDetailsPageProps {
  onNavigate: (page: 'booking', data?: any) => void;
  packageData: any;
}

export function PackageDetailsPage({ onNavigate, packageData }: PackageDetailsPageProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'itinerary' | 'inclusions' | 'reviews'>('overview');

  const pkg = packageData || {
    title: 'Maldives Paradise Escape',
    location: 'Maldives',
    image: 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080',
    duration: '5 Days / 4 Nights',
    rating: 4.8,
    reviews: 324,
    price: 1299
  };

  const galleryImages = [
    'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1738407282253-979e31f45785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHBvb2x8ZW58MXx8fHwxNzY1MDI2MTM2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1660315250109-075f6b142ebc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2V8ZW58MXx8fHwxNzY0OTg0MzkxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1639662950964-d4d1b103c7bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB0cmF2ZWx8ZW58MXx8fHwxNzY0OTUwMzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwaW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc2NTAwNzEwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1633942515749-f93dddbbcff9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2lzcyUyMGFscHMlMjBtb3VudGFpbnN8ZW58MXx8fHwxNzY0OTM0MTExfDA&ixlib=rb-4.1.0&q=80&w=1080'
  ];

  const itinerary = [
    {
      day: 1,
      title: 'Arrival & Check-in',
      description: 'Arrive at the destination and check into your luxury resort. Evening welcome dinner and orientation.',
      activities: ['Airport pickup', 'Hotel check-in', 'Welcome dinner', 'Resort tour']
    },
    {
      day: 2,
      title: 'Beach & Water Activities',
      description: 'Enjoy a full day of water sports and beach relaxation. Snorkeling in crystal-clear waters.',
      activities: ['Breakfast buffet', 'Snorkeling tour', 'Beach lunch', 'Sunset cruise']
    },
    {
      day: 3,
      title: 'Island Exploration',
      description: 'Visit nearby islands and experience local culture. Traditional lunch with locals.',
      activities: ['Island hopping', 'Cultural tour', 'Local cuisine lunch', 'Shopping time']
    },
    {
      day: 4,
      title: 'Leisure & Spa',
      description: 'Relaxation day with optional spa treatments. Enjoy resort amenities and activities.',
      activities: ['Spa session', 'Pool time', 'Cooking class', 'Beach dinner']
    },
    {
      day: 5,
      title: 'Departure',
      description: 'Last minute shopping and check-out. Transfer to airport for departure.',
      activities: ['Breakfast', 'Check-out', 'Souvenir shopping', 'Airport transfer']
    }
  ];

  const inclusions = [
    { icon: Hotel, text: '4 nights accommodation in luxury resort' },
    { icon: Utensils, text: 'Daily breakfast and 3 dinners included' },
    { icon: Plane, text: 'Round-trip airport transfers' },
    { icon: Users, text: 'Professional tour guide' },
    { icon: Camera, text: 'All sightseeing tours as per itinerary' },
    { icon: CheckCircle, text: 'Travel insurance coverage' },
    { icon: CheckCircle, text: 'All taxes and service charges' },
    { icon: CheckCircle, text: '24/7 customer support' }
  ];

  const reviews = [
    { name: 'Sarah Johnson', rating: 5, date: 'November 2024', text: 'Absolutely amazing experience! The resort was stunning and the staff were incredibly friendly. Highly recommend!' },
    { name: 'Michael Chen', rating: 5, date: 'October 2024', text: 'Best vacation ever! Every detail was perfectly planned. The snorkeling tour was unforgettable.' },
    { name: 'Emma Davis', rating: 4, date: 'September 2024', text: 'Great trip overall. Beautiful location and well-organized activities. Would love to go back!' },
    { name: 'James Wilson', rating: 5, date: 'August 2024', text: 'Perfect honeymoon destination. The overwater villa was luxurious and the sunset cruises were magical.' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Banner */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={pkg.image}
          alt={pkg.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10">
        <div className="bg-white rounded-2xl shadow-2xl p-8 mb-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            <div className="flex-1">
              <div className="flex items-center gap-2 text-gray-600 mb-3">
                <MapPin className="w-5 h-5 text-blue-600" />
                <span>{pkg.location}</span>
              </div>
              <h1 className="text-4xl mb-4">{pkg.title}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full">
                  <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                  <span>{pkg.rating}</span>
                  <span className="text-gray-400">({pkg.reviews} reviews)</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-5 h-5" />
                  <span>{pkg.duration}</span>
                </div>
              </div>
            </div>
            <div className="lg:text-right">
              <span className="text-gray-500 block mb-1">Starting from</span>
              <div className="text-5xl text-blue-600 mb-2">${pkg.price}</div>
              <span className="text-gray-500">per person</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tabs */}
            <div className="bg-white rounded-2xl shadow-md overflow-hidden">
              <div className="flex border-b">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    activeTab === 'overview'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('itinerary')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    activeTab === 'itinerary'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  Itinerary
                </button>
                <button
                  onClick={() => setActiveTab('inclusions')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    activeTab === 'inclusions'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  Inclusions
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`flex-1 py-4 px-6 transition-colors ${
                    activeTab === 'reviews'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  Reviews
                </button>
              </div>

              <div className="p-8">
                {activeTab === 'overview' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-2xl mb-4">About This Tour</h3>
                      <p className="text-gray-600 leading-relaxed mb-4">
                        Embark on an unforgettable journey to one of the world{"'"}s most beautiful destinations. 
                        This carefully curated package offers the perfect blend of relaxation, adventure, and cultural experiences.
                      </p>
                      <p className="text-gray-600 leading-relaxed">
                        Whether you{"'"}re looking for a romantic getaway, a family vacation, or an adventure with friends, 
                        this tour has something for everyone. Enjoy pristine beaches, crystal-clear waters, world-class 
                        accommodations, and authentic local experiences that will create memories to last a lifetime.
                      </p>
                    </div>

                    <div>
                      <h3 className="text-2xl mb-4">Highlights</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {[
                          'Luxury beachfront accommodation',
                          'Daily gourmet breakfast',
                          'Guided sightseeing tours',
                          'Water sports activities',
                          'Sunset cruise experience',
                          'Cultural immersion activities',
                          'Professional photography session',
                          'Complimentary spa treatment'
                        ].map((highlight, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-500" />
                            <span className="text-gray-700">{highlight}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'itinerary' && (
                  <div>
                    <h3 className="text-2xl mb-6">Day-by-Day Itinerary</h3>
                    <div className="space-y-6">
                      {itinerary.map((item) => (
                        <div key={item.day} className="relative pl-8 pb-6 border-l-2 border-blue-200 last:border-l-0">
                          <div className="absolute -left-3 top-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs">{item.day}</span>
                          </div>
                          <div className="bg-gray-50 rounded-xl p-6">
                            <h4 className="text-xl mb-2">Day {item.day}: {item.title}</h4>
                            <p className="text-gray-600 mb-4">{item.description}</p>
                            <div className="grid grid-cols-2 gap-2">
                              {item.activities.map((activity, index) => (
                                <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                                  <ChevronRight className="w-4 h-4 text-blue-600" />
                                  <span>{activity}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'inclusions' && (
                  <div>
                    <h3 className="text-2xl mb-6">What{"'"}s Included</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {inclusions.map((item, index) => (
                        <div key={index} className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <item.icon className="w-5 h-5 text-blue-600" />
                          </div>
                          <span className="text-gray-700 pt-2">{item.text}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-8 p-6 bg-red-50 rounded-xl">
                      <h4 className="text-lg mb-3">Not Included</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• International flights</li>
                        <li>• Personal expenses and shopping</li>
                        <li>• Additional meals not mentioned</li>
                        <li>• Optional activities and excursions</li>
                      </ul>
                    </div>
                  </div>
                )}

                {activeTab === 'reviews' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-2xl">Guest Reviews</h3>
                      <div className="flex items-center gap-2">
                        <Star className="w-6 h-6 text-yellow-500 fill-yellow-500" />
                        <span className="text-2xl">{pkg.rating}</span>
                        <span className="text-gray-500">({pkg.reviews} reviews)</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      {reviews.map((review, index) => (
                        <div key={index} className="p-6 bg-gray-50 rounded-xl">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="mb-1">{review.name}</h4>
                              <span className="text-sm text-gray-500">{review.date}</span>
                            </div>
                            <div className="flex">
                              {[...Array(review.rating)].map((_, i) => (
                                <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                              ))}
                            </div>
                          </div>
                          <p className="text-gray-700">{review.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Gallery */}
            <div className="bg-white rounded-2xl shadow-md p-8">
              <h3 className="text-2xl mb-6">Photo Gallery</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {galleryImages.map((image, index) => (
                  <div
                    key={index}
                    className="relative h-48 rounded-xl overflow-hidden group cursor-pointer"
                  >
                    <img
                      src={image}
                      alt={`Gallery ${index + 1}`}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sticky Booking Card */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white rounded-2xl shadow-md p-6">
              <div className="mb-6">
                <span className="text-gray-500 text-sm">Starting from</span>
                <div className="text-4xl text-blue-600 mb-1">${pkg.price}</div>
                <span className="text-gray-500">per person</span>
              </div>

              <div className="space-y-4 mb-6">
                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-2 text-gray-600 mb-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span className="text-sm">Select Date</span>
                  </div>
                  <input
                    type="date"
                    className="w-full p-2 bg-white border border-gray-200 rounded-lg outline-none focus:border-blue-600"
                  />
                </div>

                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-2 text-gray-600 mb-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span className="text-sm">Travelers</span>
                  </div>
                  <select className="w-full p-2 bg-white border border-gray-200 rounded-lg outline-none focus:border-blue-600">
                    <option>1 Adult</option>
                    <option>2 Adults</option>
                    <option>2 Adults, 1 Child</option>
                    <option>2 Adults, 2 Children</option>
                  </select>
                </div>
              </div>

              <button
                onClick={() => onNavigate('booking', pkg)}
                className="w-full py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 mb-4"
              >
                Book This Trip
              </button>

              <div className="space-y-3 pt-4 border-t">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Free cancellation up to 48 hours</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Instant confirmation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Best price guarantee</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
