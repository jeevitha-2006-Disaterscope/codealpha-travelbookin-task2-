import { useState } from 'react';
import { CreditCard, Smartphone, Building2, Lock, CheckCircle, ChevronRight } from 'lucide-react';
import { Footer } from './Footer';

interface PaymentPageProps {
  onNavigate: (page: 'confirmation', data?: any) => void;
  packageData: any;
}

export function PaymentPage({ onNavigate, packageData }: PaymentPageProps) {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'upi' | 'netbanking'>('card');

  const pkg = packageData || {
    title: 'Maldives Paradise Escape',
    location: 'Maldives',
    price: 1299
  };

  const travelers = 2;
  const basePrice = pkg.price * travelers;
  const taxes = basePrice * 0.15;
  const total = basePrice + taxes;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl mb-2">Complete Your Payment</h1>
          <p className="text-gray-600">Secure payment powered by industry-leading encryption</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-md p-8">
              {/* Payment Method Selection */}
              <h2 className="text-2xl mb-6">Select Payment Method</h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`p-6 border-2 rounded-xl transition-all duration-300 ${
                    paymentMethod === 'card'
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <CreditCard className={`w-8 h-8 mx-auto mb-3 ${
                    paymentMethod === 'card' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <div className="text-center">Credit/Debit Card</div>
                </button>

                <button
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-6 border-2 rounded-xl transition-all duration-300 ${
                    paymentMethod === 'upi'
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <Smartphone className={`w-8 h-8 mx-auto mb-3 ${
                    paymentMethod === 'upi' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <div className="text-center">UPI Payment</div>
                </button>

                <button
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-6 border-2 rounded-xl transition-all duration-300 ${
                    paymentMethod === 'netbanking'
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <Building2 className={`w-8 h-8 mx-auto mb-3 ${
                    paymentMethod === 'netbanking' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <div className="text-center">Net Banking</div>
                </button>
              </div>

              {/* Credit Card Form */}
              {paymentMethod === 'card' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-600 mb-2 text-sm">Card Number</label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="1234 5678 9012 3456"
                        maxLength={19}
                        className="w-full p-4 pr-12 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                      <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-600 mb-2 text-sm">Cardholder Name</label>
                    <input
                      type="text"
                      placeholder="John Doe"
                      className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-600 mb-2 text-sm">Expiry Date</label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        maxLength={5}
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-600 mb-2 text-sm">CVV</label>
                      <input
                        type="text"
                        placeholder="123"
                        maxLength={3}
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl">
                    <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-gray-600">
                      <p>Your payment information is encrypted and secure. We use industry-standard SSL encryption to protect your data.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* UPI Form */}
              {paymentMethod === 'upi' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-600 mb-2 text-sm">UPI ID</label>
                    <input
                      type="text"
                      placeholder="yourname@upi"
                      className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                    />
                  </div>

                  <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl text-center">
                    <Smartphone className="w-16 h-16 mx-auto mb-4 text-blue-600" />
                    <h3 className="text-xl mb-2">Scan QR Code</h3>
                    <p className="text-gray-600 mb-4">Or enter your UPI ID above</p>
                    <div className="w-48 h-48 mx-auto bg-white rounded-xl shadow-md flex items-center justify-center">
                      <span className="text-gray-400">QR Code</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl">
                    <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-gray-600">
                      <p>Supported UPI apps: Google Pay, PhonePe, Paytm, BHIM, and more.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Net Banking Form */}
              {paymentMethod === 'netbanking' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-600 mb-2 text-sm">Select Your Bank</label>
                    <select className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors">
                      <option value="">Choose your bank</option>
                      <option>State Bank of India</option>
                      <option>HDFC Bank</option>
                      <option>ICICI Bank</option>
                      <option>Axis Bank</option>
                      <option>Punjab National Bank</option>
                      <option>Bank of Baroda</option>
                      <option>Kotak Mahindra Bank</option>
                      <option>Yes Bank</option>
                      <option>Other Banks</option>
                    </select>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                    <Building2 className="w-12 h-12 text-blue-600 mb-3" />
                    <h3 className="text-xl mb-2">Secure Bank Transfer</h3>
                    <p className="text-gray-600">
                      You will be redirected to your bank{"'"}s secure login page to complete the payment.
                    </p>
                  </div>

                  <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl">
                    <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-gray-600">
                      <p>All transactions are processed through your bank{"'"}s secure gateway. We do not store your banking credentials.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Payment Button */}
              <button
                onClick={() => onNavigate('confirmation')}
                className="w-full mt-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                <Lock className="w-5 h-5" />
                <span>Pay ${total.toLocaleString()} Securely</span>
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Security Badges */}
              <div className="mt-6 flex items-center justify-center gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span>SSL Secured</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>PCI Compliant</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>256-bit Encryption</span>
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white rounded-2xl shadow-md p-6">
              <h3 className="text-xl mb-4">Order Summary</h3>

              <div className="mb-6">
                <img
                  src={pkg.image || 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080'}
                  alt={pkg.title}
                  className="w-full h-32 object-cover rounded-xl mb-3"
                />
                <h4 className="mb-1">{pkg.title}</h4>
                <p className="text-sm text-gray-600">{pkg.location}</p>
              </div>

              <div className="space-y-3 pb-4 mb-4 border-b">
                <div className="flex justify-between">
                  <span className="text-gray-600">Package Price</span>
                  <span>${pkg.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Number of Travelers</span>
                  <span>{travelers}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span>${basePrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Taxes & Fees (15%)</span>
                  <span>${taxes.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6 pb-6 border-b">
                <span className="text-xl">Total Amount</span>
                <span className="text-3xl text-blue-600">${total.toLocaleString()}</span>
              </div>

              {/* Trust Indicators */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <span>100% Secure Payment</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <span>Instant Booking Confirmation</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <span>Free Cancellation Available</span>
                </div>
              </div>

              {/* Safe Payment Badge */}
              <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-5 h-5 text-green-600" />
                  <span className="text-green-800">Safe Payment Guarantee</span>
                </div>
                <p className="text-sm text-green-700">
                  Your payment is protected by bank-level security and encryption.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
