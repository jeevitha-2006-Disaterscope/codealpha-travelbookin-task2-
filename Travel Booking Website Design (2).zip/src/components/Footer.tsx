import { Plane, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 text-white mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full flex items-center justify-center">
                <Plane className="w-5 h-5 text-white transform -rotate-45" />
              </div>
              <span className="text-xl">TravelXplore</span>
            </div>
            <p className="text-gray-300 mb-4">
              Discover the world with us. Your adventure begins here.
            </p>
            <div className="flex gap-3">
              <button className="w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors">
                <Facebook className="w-4 h-4" />
              </button>
              <button className="w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors">
                <Twitter className="w-4 h-4" />
              </button>
              <button className="w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors">
                <Instagram className="w-4 h-4" />
              </button>
              <button className="w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors">
                <Youtube className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-300">
              <li><button className="hover:text-cyan-400 transition-colors">About Us</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Destinations</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Tour Packages</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Special Offers</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Blog</button></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="mb-4">Support</h3>
            <ul className="space-y-2 text-gray-300">
              <li><button className="hover:text-cyan-400 transition-colors">Contact Us</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">FAQs</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Booking Policy</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Privacy Policy</button></li>
              <li><button className="hover:text-cyan-400 transition-colors">Terms & Conditions</button></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4">Contact</h3>
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start gap-2">
                <MapPin className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <span>123 Travel Street, Adventure City, TC 12345</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <span>info@travelxplore.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 TravelXplore. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
