import { useState, useEffect } from 'react';
import { Search, Calendar, Users, MapPin, Star, ArrowRight, Plane, Sparkles, TrendingUp, ChevronLeft, ChevronRight } from 'lucide-react';
import { Footer } from './Footer';

interface HomePageProps {
  onNavigate: (page: 'search' | 'details', data?: any) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [activeDestination, setActiveDestination] = useState(0);

  const destinations = [
    {
      name: 'Maldives',
      image: 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '120+ Tours'
    },
    {
      name: 'Santorini',
      image: 'https://images.unsplash.com/photo-1639662950964-d4d1b103c7bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB0cmF2ZWx8ZW58MXx8fHwxNzY0OTUwMzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '85+ Tours'
    },
    {
      name: 'Paris',
      image: 'https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc2NDk4ODA5Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '200+ Tours'
    },
    {
      name: 'Dubai',
      image: 'https://images.unsplash.com/photo-1657106251952-2d584ebdf886?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMHNreWxpbmUlMjBuaWdodHxlbnwxfHx8fDE3NjUwMDU5NDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '150+ Tours'
    },
    {
      name: 'Bali',
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwaW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc2NTAwNzEwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '95+ Tours'
    },
    {
      name: 'Swiss Alps',
      image: 'https://images.unsplash.com/photo-1633942515749-f93dddbbcff9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2lzcyUyMGFscHMlMjBtb3VudGFpbnN8ZW58MXx8fHwxNzY0OTM0MTExfDA&ixlib=rb-4.1.0&q=80&w=1080',
      tours: '60+ Tours'
    }
  ];

  const packages = [
    {
      id: 1,
      title: 'Maldives Paradise Escape',
      location: 'Maldives',
      image: 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5 Days / 4 Nights',
      rating: 4.8,
      reviews: 324,
      price: 1299
    },
    {
      id: 2,
      title: 'Greek Island Adventure',
      location: 'Santorini, Greece',
      image: 'https://images.unsplash.com/photo-1639662950964-d4d1b103c7bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB0cmF2ZWx8ZW58MXx8fHwxNzY0OTUwMzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '7 Days / 6 Nights',
      rating: 4.9,
      reviews: 512,
      price: 1599
    },
    {
      id: 3,
      title: 'Paris Romance Package',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc2NDk4ODA5Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '6 Days / 5 Nights',
      rating: 4.7,
      reviews: 428,
      price: 1899
    },
    {
      id: 4,
      title: 'Dubai Luxury Experience',
      location: 'Dubai, UAE',
      image: 'https://images.unsplash.com/photo-1657106251952-2d584ebdf886?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMHNreWxpbmUlMjBuaWdodHxlbnwxfHx8fDE3NjUwMDU5NDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '4 Days / 3 Nights',
      rating: 4.6,
      reviews: 289,
      price: 999
    },
    {
      id: 5,
      title: 'Bali Cultural Journey',
      location: 'Bali, Indonesia',
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwaW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc2NTAwNzEwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '8 Days / 7 Nights',
      rating: 4.8,
      reviews: 376,
      price: 1199
    },
    {
      id: 6,
      title: 'Swiss Alps Retreat',
      location: 'Switzerland',
      image: 'https://images.unsplash.com/photo-1633942515749-f93dddbbcff9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2lzcyUyMGFscHMlMjBtb3VudGFpbnN8ZW58MXx8fHwxNzY0OTM0MTExfDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5 Days / 4 Nights',
      rating: 4.9,
      reviews: 445,
      price: 2199
    }
  ];

  const offers = [
    {
      title: 'Tokyo Explorer',
      image: 'https://images.unsplash.com/photo-1648871647634-0c99b483cb63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGphcGFuJTIwY2l0eXNjYXBlfGVufDF8fHx8MTc2NDk3MDc3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      discount: '35% OFF',
      originalPrice: 1599,
      price: 1039
    },
    {
      title: 'Iceland Northern Lights',
      image: 'https://images.unsplash.com/photo-1488415032361-b7e238421f1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VsYW5kJTIwbm9ydGhlcm4lMjBsaWdodHN8ZW58MXx8fHwxNzY0OTM4MDIyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      discount: '40% OFF',
      originalPrice: 2499,
      price: 1499
    },
    {
      title: 'African Safari',
      image: 'https://images.unsplash.com/photo-1728466852402-f233aed0d299?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWZhcmklMjB3aWxkbGlmZSUyMGFmcmljYXxlbnwxfHx8fDE3NjQ5NjA4ODd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      discount: '30% OFF',
      originalPrice: 2899,
      price: 2029
    }
  ];

  const nextDestination = () => {
    setActiveDestination((prev) => (prev + 1) % destinations.length);
  };

  const prevDestination = () => {
    setActiveDestination((prev) => (prev - 1 + destinations.length) % destinations.length);
  };

  useEffect(() => {
    const interval = setInterval(nextDestination, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[600px] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1660315250109-075f6b142ebc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2V8ZW58MXx8fHwxNzY0OTg0MzkxfDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/70 via-blue-800/50 to-transparent" />
        </div>

        {/* Animated Floating Elements */}
        <div className="absolute top-20 right-20 animate-bounce">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Plane className="w-8 h-8 text-white transform rotate-45" />
          </div>
        </div>

        {/* Hero Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-yellow-400" />
              <span className="text-cyan-300">Discover Your Next Adventure</span>
            </div>
            <h1 className="text-5xl md:text-6xl text-white mb-6">
              Explore the World
              <br />
              <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                With Confidence
              </span>
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Unforgettable journeys, handcrafted experiences, and memories that last a lifetime
            </p>

            {/* Search Bar */}
            <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <input
                    type="text"
                    placeholder="From"
                    className="bg-transparent outline-none flex-1"
                  />
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <input
                    type="text"
                    placeholder="To"
                    className="bg-transparent outline-none flex-1"
                  />
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <input
                    type="text"
                    placeholder="Dates"
                    className="bg-transparent outline-none flex-1"
                  />
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <Users className="w-5 h-5 text-blue-600" />
                  <input
                    type="text"
                    placeholder="Travelers"
                    className="bg-transparent outline-none flex-1"
                  />
                </div>
              </div>
              <button
                onClick={() => onNavigate('search')}
                className="w-full mt-4 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                <Search className="w-5 h-5" />
                <span>Search Tours</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Dotted Route Line Decoration */}
        <svg className="absolute bottom-10 left-10 w-64 h-32 opacity-30" viewBox="0 0 200 100">
          <path
            d="M 10 50 Q 60 10, 100 50 T 190 50"
            stroke="white"
            strokeWidth="2"
            strokeDasharray="5,5"
            fill="none"
          />
        </svg>
      </section>

      {/* Popular Destinations Carousel */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              <span className="text-blue-600">Popular Choices</span>
            </div>
            <h2 className="text-3xl">Top Destinations</h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={prevDestination}
              className="w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-blue-50 transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-blue-600" />
            </button>
            <button
              onClick={nextDestination}
              className="w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-blue-50 transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-blue-600" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {destinations.slice(activeDestination, activeDestination + 3).map((dest, index) => (
            <div
              key={index}
              className="group relative h-80 rounded-2xl overflow-hidden cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-2xl"
            >
              <img
                src={dest.image}
                alt={dest.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-2xl text-white mb-1">{dest.name}</h3>
                <p className="text-cyan-300">{dest.tours}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Recommended Packages */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
            <span className="text-blue-600">Hand-Picked For You</span>
          </div>
          <h2 className="text-3xl mb-4">Recommended Packages</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Curated travel experiences designed to create unforgettable memories
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 group cursor-pointer"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={pkg.image}
                  alt={pkg.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm">
                  {pkg.duration}
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 text-gray-600 mb-2">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{pkg.location}</span>
                </div>
                <h3 className="text-xl mb-3">{pkg.title}</h3>
                <div className="flex items-center gap-1 mb-4">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span>{pkg.rating}</span>
                  <span className="text-gray-400">({pkg.reviews} reviews)</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-gray-500 text-sm">From</span>
                    <div className="text-2xl text-blue-600">${pkg.price}</div>
                  </div>
                  <button
                    onClick={() => onNavigate('details', pkg)}
                    className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-lg transition-all duration-300 group/btn flex items-center gap-2"
                  >
                    View Details
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Special Offers */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-yellow-500" />
            <span className="text-blue-600">Limited Time Only</span>
          </div>
          <h2 className="text-3xl mb-4">Special Offers</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Don{"'"}t miss out on these incredible deals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {offers.map((offer, index) => (
            <div
              key={index}
              className="relative bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 group cursor-pointer"
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={offer.image}
                  alt={offer.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-gradient-to-r from-red-500 to-pink-500 text-white px-4 py-2 rounded-full shadow-lg">
                  {offer.discount}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl mb-4">{offer.title}</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-gray-400 line-through">${offer.originalPrice}</span>
                  <span className="text-3xl text-blue-600">${offer.price}</span>
                </div>
                <button className="w-full mt-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-lg transition-all duration-300">
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}
