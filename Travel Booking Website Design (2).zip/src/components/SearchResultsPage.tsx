import { useState } from 'react';
import { Search, SlidersHorizontal, DollarSign, Clock, MapPin, Star, ArrowRight, Calendar, Users } from 'lucide-react';
import { Footer } from './Footer';

interface SearchResultsPageProps {
  onNavigate: (page: 'details', data?: any) => void;
}

export function SearchResultsPage({ onNavigate }: SearchResultsPageProps) {
  const [priceRange, setPriceRange] = useState([0, 5000]);
  const [selectedDuration, setSelectedDuration] = useState<string[]>([]);
  const [selectedRating, setSelectedRating] = useState<number>(0);

  const packages = [
    {
      id: 1,
      title: 'Maldives Paradise Escape',
      location: 'Maldives',
      image: 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5 Days / 4 Nights',
      rating: 4.8,
      reviews: 324,
      price: 1299,
      description: 'Experience pristine beaches, crystal-clear waters, and luxury overwater villas'
    },
    {
      id: 2,
      title: 'Greek Island Adventure',
      location: 'Santorini, Greece',
      image: 'https://images.unsplash.com/photo-1639662950964-d4d1b103c7bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB0cmF2ZWx8ZW58MXx8fHwxNzY0OTUwMzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '7 Days / 6 Nights',
      rating: 4.9,
      reviews: 512,
      price: 1599,
      description: 'Discover stunning sunsets, white-washed buildings, and Mediterranean cuisine'
    },
    {
      id: 3,
      title: 'Paris Romance Package',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc2NDk4ODA5Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '6 Days / 5 Nights',
      rating: 4.7,
      reviews: 428,
      price: 1899,
      description: 'Explore iconic landmarks, world-class museums, and charming cafés'
    },
    {
      id: 4,
      title: 'Dubai Luxury Experience',
      location: 'Dubai, UAE',
      image: 'https://images.unsplash.com/photo-1657106251952-2d584ebdf886?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMHNreWxpbmUlMjBuaWdodHxlbnwxfHx8fDE3NjUwMDU5NDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '4 Days / 3 Nights',
      rating: 4.6,
      reviews: 289,
      price: 999,
      description: 'Experience luxury shopping, modern architecture, and desert adventures'
    },
    {
      id: 5,
      title: 'Bali Cultural Journey',
      location: 'Bali, Indonesia',
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwaW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc2NTAwNzEwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '8 Days / 7 Nights',
      rating: 4.8,
      reviews: 376,
      price: 1199,
      description: 'Immerse in rich culture, ancient temples, and lush rice terraces'
    },
    {
      id: 6,
      title: 'Swiss Alps Retreat',
      location: 'Switzerland',
      image: 'https://images.unsplash.com/photo-1633942515749-f93dddbbcff9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2lzcyUyMGFscHMlMjBtb3VudGFpbnN8ZW58MXx8fHwxNzY0OTM0MTExfDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5 Days / 4 Nights',
      rating: 4.9,
      reviews: 445,
      price: 2199,
      description: 'Breathtaking mountain views, pristine lakes, and charming alpine villages'
    },
    {
      id: 7,
      title: 'Tokyo Explorer',
      location: 'Tokyo, Japan',
      image: 'https://images.unsplash.com/photo-1648871647634-0c99b483cb63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGphcGFuJTIwY2l0eXNjYXBlfGVufDF8fHx8MTc2NDk3MDc3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '6 Days / 5 Nights',
      rating: 4.7,
      reviews: 398,
      price: 1599,
      description: 'Experience the perfect blend of traditional culture and modern technology'
    },
    {
      id: 8,
      title: 'Iceland Northern Lights',
      location: 'Iceland',
      image: 'https://images.unsplash.com/photo-1488415032361-b7e238421f1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VsYW5kJTIwbm9ydGhlcm4lMjBsaWdodHN8ZW58MXx8fHwxNzY0OTM4MDIyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '7 Days / 6 Nights',
      rating: 4.9,
      reviews: 567,
      price: 2499,
      description: 'Chase the aurora borealis and explore dramatic landscapes'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sticky Search Bar */}
      <div className="sticky top-16 z-40 bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <MapPin className="w-5 h-5 text-blue-600" />
              <input
                type="text"
                placeholder="Destination"
                className="bg-transparent outline-none flex-1"
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <Calendar className="w-5 h-5 text-blue-600" />
              <input
                type="text"
                placeholder="Check-in"
                className="bg-transparent outline-none flex-1"
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <Calendar className="w-5 h-5 text-blue-600" />
              <input
                type="text"
                placeholder="Check-out"
                className="bg-transparent outline-none flex-1"
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <Users className="w-5 h-5 text-blue-600" />
              <input
                type="text"
                placeholder="Travelers"
                className="bg-transparent outline-none flex-1"
              />
            </div>
            <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2">
              <Search className="w-5 h-5" />
              <span>Search</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Left Sidebar - Filters */}
          <aside className="hidden lg:block w-72 flex-shrink-0">
            <div className="sticky top-36 bg-white rounded-2xl shadow-md p-6">
              <div className="flex items-center gap-2 mb-6">
                <SlidersHorizontal className="w-5 h-5 text-blue-600" />
                <h3 className="text-xl">Filters</h3>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-5 h-5 text-blue-600" />
                  <h4>Price Range</h4>
                </div>
                <div className="space-y-3">
                  <input
                    type="range"
                    min="0"
                    max="5000"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>
              </div>

              {/* Duration */}
              <div className="mb-6 pb-6 border-b">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <h4>Duration</h4>
                </div>
                <div className="space-y-2">
                  {['1-3 Days', '4-6 Days', '7-10 Days', '10+ Days'].map((duration) => (
                    <label key={duration} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={selectedDuration.includes(duration)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedDuration([...selectedDuration, duration]);
                          } else {
                            setSelectedDuration(selectedDuration.filter(d => d !== duration));
                          }
                        }}
                        className="w-4 h-4 text-blue-600 rounded"
                      />
                      <span className="text-gray-700 group-hover:text-blue-600 transition-colors">
                        {duration}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Rating */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-blue-600" />
                  <h4>Minimum Rating</h4>
                </div>
                <div className="space-y-2">
                  {[5, 4, 3].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => setSelectedRating(rating)}
                      className={`w-full flex items-center gap-2 p-2 rounded-lg transition-colors ${
                        selectedRating === rating ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex">
                        {[...Array(rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <span>& up</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Reset Filters */}
              <button className="w-full py-3 border-2 border-blue-600 text-blue-600 rounded-xl hover:bg-blue-50 transition-colors">
                Reset Filters
              </button>
            </div>
          </aside>

          {/* Right Side - Results */}
          <main className="flex-1">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl mb-1">Search Results</h2>
                <p className="text-gray-600">{packages.length} packages found</p>
              </div>
              <select className="px-4 py-2 bg-white border border-gray-200 rounded-xl outline-none focus:border-blue-600 transition-colors">
                <option>Sort by: Recommended</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Rating: High to Low</option>
                <option>Duration: Shortest</option>
              </select>
            </div>

            <div className="space-y-6">
              {packages.map((pkg) => (
                <div
                  key={pkg.id}
                  className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group cursor-pointer"
                >
                  <div className="md:flex">
                    {/* Image */}
                    <div className="md:w-96 h-64 md:h-auto relative overflow-hidden flex-shrink-0">
                      <img
                        src={pkg.image}
                        alt={pkg.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm">
                        {pkg.duration}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-6 flex flex-col">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 text-gray-600 mb-2">
                              <MapPin className="w-4 h-4" />
                              <span className="text-sm">{pkg.location}</span>
                            </div>
                            <h3 className="text-2xl mb-2">{pkg.title}</h3>
                            <p className="text-gray-600">{pkg.description}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 mb-4">
                          <div className="flex items-center gap-1 bg-blue-50 px-3 py-1 rounded-full">
                            <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                            <span>{pkg.rating}</span>
                          </div>
                          <span className="text-gray-400">({pkg.reviews} reviews)</span>
                        </div>
                      </div>

                      <div className="flex items-end justify-between pt-4 border-t">
                        <div>
                          <span className="text-gray-500 text-sm">Starting from</span>
                          <div className="flex items-baseline gap-2">
                            <span className="text-3xl text-blue-600">${pkg.price}</span>
                            <span className="text-gray-500">/ person</span>
                          </div>
                        </div>
                        <button
                          onClick={() => onNavigate('details', pkg)}
                          className="px-8 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-lg transition-all duration-300 flex items-center gap-2 group/btn"
                        >
                          <span>Book Now</span>
                          <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </main>
        </div>
      </div>

      <Footer />
    </div>
  );
}
