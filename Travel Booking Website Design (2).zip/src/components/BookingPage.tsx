import { useState } from 'react';
import { User, Mail, Phone, MapPin, CreditCard, Calendar, Users, CheckCircle, ChevronRight } from 'lucide-react';
import { Footer } from './Footer';

interface BookingPageProps {
  onNavigate: (page: 'payment', data?: any) => void;
  packageData: any;
}

export function BookingPage({ onNavigate, packageData }: BookingPageProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [travelers, setTravelers] = useState(2);

  const pkg = packageData || {
    title: 'Maldives Paradise Escape',
    location: 'Maldives',
    duration: '5 Days / 4 Nights',
    price: 1299
  };

  const basePrice = pkg.price * travelers;
  const taxes = basePrice * 0.15;
  const total = basePrice + taxes;

  const steps = [
    { number: 1, title: 'Traveler Details' },
    { number: 2, title: 'Review & Confirm' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Progress Steps */}
        <div className="mb-12">
          <div className="flex items-center justify-center">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                      currentStep >= step.number
                        ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-lg'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {currentStep > step.number ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : (
                      <span>{step.number}</span>
                    )}
                  </div>
                  <span className="mt-2 text-sm text-gray-600">{step.title}</span>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`w-32 h-1 mx-4 transition-colors duration-300 ${
                      currentStep > step.number ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            {currentStep === 1 && (
              <div className="bg-white rounded-2xl shadow-md p-8">
                <h2 className="text-2xl mb-6">Traveler Information</h2>

                {/* Number of Travelers */}
                <div className="mb-8 p-6 bg-blue-50 rounded-xl">
                  <label className="flex items-center gap-2 mb-3">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span>Number of Travelers</span>
                  </label>
                  <select
                    value={travelers}
                    onChange={(e) => setTravelers(parseInt(e.target.value))}
                    className="w-full p-3 bg-white border border-gray-200 rounded-xl outline-none focus:border-blue-600"
                  >
                    <option value={1}>1 Adult</option>
                    <option value={2}>2 Adults</option>
                    <option value={3}>2 Adults, 1 Child</option>
                    <option value={4}>2 Adults, 2 Children</option>
                  </select>
                </div>

                {/* Primary Traveler */}
                <div className="mb-8">
                  <h3 className="text-xl mb-4">Primary Traveler</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <User className="w-4 h-4" />
                        <span className="text-sm">First Name</span>
                      </label>
                      <input
                        type="text"
                        placeholder="John"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <User className="w-4 h-4" />
                        <span className="text-sm">Last Name</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Doe"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <Mail className="w-4 h-4" />
                        <span className="text-sm">Email</span>
                      </label>
                      <input
                        type="email"
                        placeholder="john.doe@example.com"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <Phone className="w-4 h-4" />
                        <span className="text-sm">Phone</span>
                      </label>
                      <input
                        type="tel"
                        placeholder="+1 (555) 123-4567"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                  </div>
                </div>

                {/* Travel Dates */}
                <div className="mb-8">
                  <h3 className="text-xl mb-4">Travel Dates</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <Calendar className="w-4 h-4" />
                        <span className="text-sm">Departure Date</span>
                      </label>
                      <input
                        type="date"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <Calendar className="w-4 h-4" />
                        <span className="text-sm">Return Date</span>
                      </label>
                      <input
                        type="date"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                  </div>
                </div>

                {/* Additional Details */}
                <div className="mb-8">
                  <h3 className="text-xl mb-4">Additional Information</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="flex items-center gap-2 text-gray-600 mb-2">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">Address</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Street Address"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <input
                        type="text"
                        placeholder="City"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                      <input
                        type="text"
                        placeholder="ZIP Code"
                        className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors"
                      />
                    </div>
                  </div>
                </div>

                {/* Special Requests */}
                <div className="mb-8">
                  <h3 className="text-xl mb-4">Special Requests (Optional)</h3>
                  <textarea
                    placeholder="Any special requirements or preferences..."
                    rows={4}
                    className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-blue-600 focus:bg-white transition-colors resize-none"
                  />
                </div>

                <button
                  onClick={() => setCurrentStep(2)}
                  className="w-full py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group"
                >
                  <span>Continue to Review</span>
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            )}

            {currentStep === 2 && (
              <div className="bg-white rounded-2xl shadow-md p-8">
                <h2 className="text-2xl mb-6">Review Your Booking</h2>

                {/* Trip Summary */}
                <div className="mb-6 p-6 bg-blue-50 rounded-xl">
                  <h3 className="text-xl mb-3">Trip Details</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Package:</span>
                      <span>{pkg.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Destination:</span>
                      <span>{pkg.location}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span>{pkg.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Travelers:</span>
                      <span>{travelers} {travelers === 1 ? 'Person' : 'People'}</span>
                    </div>
                  </div>
                </div>

                {/* Traveler Info */}
                <div className="mb-6 p-6 bg-gray-50 rounded-xl">
                  <h3 className="text-xl mb-3">Traveler Information</h3>
                  <div className="space-y-2 text-gray-600">
                    <p>Name: John Doe</p>
                    <p>Email: john.doe@example.com</p>
                    <p>Phone: +1 (555) 123-4567</p>
                  </div>
                </div>

                {/* Terms and Conditions */}
                <div className="mb-6 p-6 border-2 border-gray-200 rounded-xl">
                  <h3 className="text-xl mb-4">Terms & Conditions</h3>
                  <div className="space-y-3 text-sm text-gray-600">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input type="checkbox" className="mt-1 w-4 h-4 text-blue-600 rounded" />
                      <span>I agree to the cancellation policy and understand that cancellations made within 48 hours of departure are non-refundable.</span>
                    </label>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input type="checkbox" className="mt-1 w-4 h-4 text-blue-600 rounded" />
                      <span>I have read and accept the terms and conditions, privacy policy, and booking policies.</span>
                    </label>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input type="checkbox" className="mt-1 w-4 h-4 text-blue-600 rounded" />
                      <span>I consent to receiving booking confirmation and travel updates via email and SMS.</span>
                    </label>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => onNavigate('payment', pkg)}
                    className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group"
                  >
                    <span>Proceed to Payment</span>
                    <CreditCard className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Price Summary - Sticky */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white rounded-2xl shadow-md p-6">
              <h3 className="text-xl mb-4">Price Summary</h3>

              <div className="mb-6">
                <img
                  src={pkg.image || 'https://images.unsplash.com/photo-1698726654862-377c0218dfdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc2NDk2NDAxNnww&ixlib=rb-4.1.0&q=80&w=1080'}
                  alt={pkg.title}
                  className="w-full h-32 object-cover rounded-xl mb-3"
                />
                <h4 className="mb-1">{pkg.title}</h4>
                <p className="text-sm text-gray-600">{pkg.location}</p>
              </div>

              <div className="space-y-3 pb-4 border-b">
                <div className="flex justify-between text-gray-600">
                  <span>${pkg.price} × {travelers} traveler{travelers > 1 ? 's' : ''}</span>
                  <span>${basePrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Taxes & Fees</span>
                  <span>${taxes.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 mb-6">
                <span className="text-xl">Total</span>
                <span className="text-3xl text-blue-600">${total.toLocaleString()}</span>
              </div>

              <div className="space-y-3 pt-4 border-t">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Free cancellation up to 48 hours</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Instant confirmation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Secure payment</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
