import { Plane, User, Heart, Menu } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: 'home' | 'search' | 'details' | 'booking' | 'payment' | 'confirmation') => void;
  currentPage: string;
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full flex items-center justify-center">
              <Plane className="w-5 h-5 text-white transform -rotate-45" />
            </div>
            <span className="text-xl bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
              TravelXplore
            </span>
          </button>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className={`transition-colors ${
                currentPage === 'home' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onNavigate('search')}
              className={`transition-colors ${
                currentPage === 'search' ? 'text-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Explore
            </button>
            <button className="text-gray-700 hover:text-blue-600 transition-colors">
              Destinations
            </button>
            <button className="text-gray-700 hover:text-blue-600 transition-colors">
              Deals
            </button>
            <button className="text-gray-700 hover:text-blue-600 transition-colors">
              About
            </button>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-600 hover:text-blue-600 transition-colors">
              <Heart className="w-5 h-5" />
            </button>
            <button className="p-2 text-gray-600 hover:text-blue-600 transition-colors">
              <User className="w-5 h-5" />
            </button>
            <button className="md:hidden p-2 text-gray-600 hover:text-blue-600 transition-colors">
              <Menu className="w-5 h-5" />
            </button>
            <button className="hidden md:block px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-full hover:shadow-lg transition-all duration-300 hover:scale-105">
              Sign In
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
