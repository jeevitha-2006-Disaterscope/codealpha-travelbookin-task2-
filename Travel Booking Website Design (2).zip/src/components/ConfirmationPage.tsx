import { CheckCircle, Download, Mail, Calendar, MapPin, Users, Plane, ArrowRight } from 'lucide-react';
import { Footer } from './Footer';

interface ConfirmationPageProps {
  onNavigate: (page: 'home' | 'search') => void;
}

export function ConfirmationPage({ onNavigate }: ConfirmationPageProps) {
  const bookingId = 'TXP' + Math.random().toString(36).substr(2, 9).toUpperCase();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Animation Area */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full mb-6 animate-bounce shadow-2xl">
            <CheckCircle className="w-20 h-20 text-white" strokeWidth={2.5} />
          </div>
          <h1 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
            Booking Confirmed!
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            Your adventure awaits! Get ready for an amazing journey.
          </p>
          <p className="text-gray-500">
            A confirmation email has been sent to your registered email address.
          </p>
        </div>

        {/* Booking Details Card */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-8">
          {/* Header with Booking ID */}
          <div className="bg-gradient-to-r from-blue-600 to-cyan-500 p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm mb-1">Booking ID</p>
                <p className="text-2xl tracking-wider">{bookingId}</p>
              </div>
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                <Plane className="w-8 h-8 transform -rotate-45" />
              </div>
            </div>
          </div>

          {/* Trip Summary */}
          <div className="p-8">
            <h2 className="text-2xl mb-6">Trip Summary</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Left Column */}
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Destination</p>
                    <p className="text-lg">Maldives Paradise Escape</p>
                    <p className="text-gray-600">Maldives</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Travel Dates</p>
                    <p className="text-lg">Dec 15, 2025 - Dec 20, 2025</p>
                    <p className="text-gray-600">5 Days / 4 Nights</p>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Travelers</p>
                    <p className="text-lg">2 Adults</p>
                    <p className="text-gray-600">John Doe (Primary)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Contact Details</p>
                    <p className="text-lg">john.doe@example.com</p>
                    <p className="text-gray-600">+1 (555) 123-4567</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Summary */}
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 mb-6">
              <h3 className="text-xl mb-4">Payment Summary</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-gray-600">
                  <span>Package Price (2 travelers)</span>
                  <span>$2,598.00</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Taxes & Fees</span>
                  <span>$389.70</span>
                </div>
                <div className="flex justify-between items-center pt-3 border-t-2 border-blue-200">
                  <span className="text-xl">Total Paid</span>
                  <span className="text-3xl text-blue-600">$2,988</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button className="flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 group">
                <Download className="w-5 h-5" />
                <span>Download Ticket</span>
              </button>
              <button className="flex items-center justify-center gap-2 py-4 border-2 border-blue-600 text-blue-600 rounded-xl hover:bg-blue-50 transition-colors group">
                <Mail className="w-5 h-5" />
                <span>Email Confirmation</span>
              </button>
            </div>
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-white rounded-2xl shadow-md p-8 mb-8">
          <h2 className="text-2xl mb-6">What{"'"}s Next?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-white">1</span>
              </div>
              <h3 className="mb-2">Check Your Email</h3>
              <p className="text-sm text-gray-600">
                We{"'"}ve sent detailed booking information and travel documents to your email.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-white">2</span>
              </div>
              <h3 className="mb-2">Prepare for Travel</h3>
              <p className="text-sm text-gray-600">
                Review the itinerary and prepare necessary documents like passport and visa.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-white">3</span>
              </div>
              <h3 className="mb-2">Contact Support</h3>
              <p className="text-sm text-gray-600">
                Our 24/7 support team is ready to help with any questions or concerns.
              </p>
            </div>
          </div>
        </div>

        {/* Important Information */}
        <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-2xl p-6 mb-8">
          <h3 className="text-xl mb-4">Important Information</h3>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <span>Please carry a printed or digital copy of your booking confirmation.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <span>Arrive at the airport at least 3 hours before international departure.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <span>Ensure your passport is valid for at least 6 months from the travel date.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <span>Free cancellation available up to 48 hours before departure.</span>
            </li>
          </ul>
        </div>

        {/* Continue Browsing */}
        <div className="text-center">
          <p className="text-gray-600 mb-6">Ready to plan your next adventure?</p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={() => onNavigate('home')}
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-xl hover:shadow-xl transition-all duration-300 flex items-center gap-2 group"
            >
              <span>Continue Browsing</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate('search')}
              className="px-8 py-4 border-2 border-blue-600 text-blue-600 rounded-xl hover:bg-blue-50 transition-colors flex items-center gap-2"
            >
              <span>Explore More Trips</span>
            </button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
